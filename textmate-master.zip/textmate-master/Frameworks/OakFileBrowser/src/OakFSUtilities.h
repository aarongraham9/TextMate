#include <OakFoundation/OakFoundation.h>

PUBLIC extern NSURL* kURLLocationComputer;
PUBLIC extern NSURL* kURLLocationHome;
PUBLIC extern NSURL* kURLLocationDesktop;
PUBLIC extern NSURL* kURLLocationFavorites;
PUBLIC extern NSURL* kURLLocationBundles;

PUBLIC NSURL* ParentForURL (NSURL* url);
