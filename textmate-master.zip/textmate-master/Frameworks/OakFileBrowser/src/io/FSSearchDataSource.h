#import "FSDataSource.h"

@interface FSSearchDataSource : FSDataSource
- (id)initWithURL:(NSURL*)anURL options:(NSUInteger)someOptions;
@end
