#import "FSDataSource.h"

@interface FSVolumesDataSource : FSDataSource
- (id)initWithURL:(NSURL*)anURL options:(NSUInteger)someOptions;
@end
