#import "FSDataSource.h"

@interface FSDirectoryDataSource : FSDataSource
- (id)initWithURL:(NSURL*)anURL options:(NSUInteger)someOptions;
@end
