#import <OakAppKit/OakGradientView.h>

@interface OFBHeaderView : OakGradientView
@property (nonatomic, retain) NSPopUpButton* folderPopUpButton;
@property (nonatomic, retain) NSButton* goBackButton;
@property (nonatomic, retain) NSButton* goForwardButton;
@end
