@interface NSDate (HumanDates)
- (NSString*)humanReadableTimeElapsed;
@end