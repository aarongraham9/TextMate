#import <oak/misc.h>

PUBLIC BOOL NSIsEmptyString (NSString* str);
PUBLIC BOOL NSNotEmptyString (NSString* str);
