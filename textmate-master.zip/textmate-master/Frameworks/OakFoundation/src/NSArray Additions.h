@interface NSArray (Other)
- (id)firstObject;
@end
