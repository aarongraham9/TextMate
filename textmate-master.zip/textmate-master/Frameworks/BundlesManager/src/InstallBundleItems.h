#import <oak/misc.h>

void InstallBundleItems (NSArray* itemPaths);
