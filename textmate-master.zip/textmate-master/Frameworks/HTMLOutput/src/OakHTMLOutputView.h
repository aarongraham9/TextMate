#import "browser/HOBrowserView.h"
#import <oak/misc.h>

PUBLIC @interface OakHTMLOutputView : HOBrowserView
@property (nonatomic, readonly) BOOL runningCommand;
@end
