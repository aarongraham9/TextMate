@interface HOAutoScroll : NSObject
@property (nonatomic) WebFrameView* webFrame;
@end
