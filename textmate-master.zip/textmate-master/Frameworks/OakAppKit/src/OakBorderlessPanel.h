@interface OakBorderlessPanel : NSPanel
{
}
@end
