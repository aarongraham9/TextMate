#import <oak/misc.h>

@interface OakSubmenuController : NSObject <NSMenuDelegate>
{
	IBOutlet NSMenu* goToMenu;
	IBOutlet NSMenu* marksMenu;
}
@end
