#ifndef IO_ALERT_PANEL_H_TGU0N94P
#define IO_ALERT_PANEL_H_TGU0N94P

#include <oak/misc.h>

PUBLIC void OakRunIOAlertPanel (char const* format, ...) __attribute__ ((format (printf, 1, 2)));

#endif /* end of include guard: IO_ALERT_PANEL_H_TGU0N94P */
