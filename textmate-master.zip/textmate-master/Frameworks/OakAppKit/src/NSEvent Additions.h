@interface NSEvent (SnowLeopardCompatibilityWrappers)
+ (NSTimeInterval)caretBlinkInterval;
@end
