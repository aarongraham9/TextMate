@interface NSWindow (Other)
- (void)toggleVisibility;
@end
