#import "OakView.h"

@interface OakControl : OakView
@property (nonatomic, readonly) NSInteger tag; // tag of the most recent layer causing an action
@end
