@interface NSMenu (Additions)
- (NSMenuItem*)parentMenuItem;
@end
