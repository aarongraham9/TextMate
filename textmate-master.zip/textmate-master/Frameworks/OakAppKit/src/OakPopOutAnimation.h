#include <oak/misc.h>

PUBLIC void OakShowPopOutAnimation (NSRect aRect, NSImage* image);
