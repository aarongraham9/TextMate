#import <oak/misc.h>

PUBLIC @interface OakEncodingPopUpButton : NSPopUpButton
@property (nonatomic) NSString* encoding;
@end
