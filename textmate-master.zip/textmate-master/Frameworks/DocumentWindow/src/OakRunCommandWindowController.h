@interface OakRunCommandWindowController : NSWindowController
+ (OakRunCommandWindowController*)sharedInstance;
@end
