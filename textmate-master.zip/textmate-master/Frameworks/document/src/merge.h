#ifndef MERGE_H_G9U6AOAI
#define MERGE_H_G9U6AOAI

std::string merge (std::string const& oldContent, std::string const& myContent, std::string const& yourContent, bool* conflict = NULL);

#endif /* end of include guard: MERGE_H_G9U6AOAI */
