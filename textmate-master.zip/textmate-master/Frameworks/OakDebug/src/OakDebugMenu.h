#ifndef NDEBUG

#ifdef __OBJC__
	@interface OakDebugMenu : NSObject { }
	@end
#endif

#endif
