@interface OakRot13Transformer : NSValueTransformer
{
}
+ (void)register;
@end
