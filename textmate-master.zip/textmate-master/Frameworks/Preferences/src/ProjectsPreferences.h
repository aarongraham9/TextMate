#import "PreferencesPane.h"

@interface ProjectsPreferences : PreferencesPane
{
	IBOutlet NSPopUpButton* fileBrowserPathPopUp;
}
@end
