#ifndef NETWORK_CONSTANTS_H_R7DVBN2M
#define NETWORK_CONSTANTS_H_R7DVBN2M

#include <oak/misc.h>

PUBLIC extern std::string const kHTTPSignatureHeader;
PUBLIC extern std::string const kHTTPSigneeHeader;

#endif /* end of include guard: NETWORK_CONSTANTS_H_R7DVBN2M */
