#include "constants.h"

std::string const kHTTPSignatureHeader = "x-amz-meta-x-signature";
std::string const kHTTPSigneeHeader    = "x-amz-meta-x-signee";
