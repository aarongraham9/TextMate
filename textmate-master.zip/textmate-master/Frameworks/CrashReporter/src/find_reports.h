#ifndef FIND_REPORTS_H_DX8YASDO
#define FIND_REPORTS_H_DX8YASDO

#include <oak/misc.h>

std::map<CFAbsoluteTime, std::string> find_reports (std::string const& process);

#endif /* end of include guard: FIND_REPORTS_H_DX8YASDO */
