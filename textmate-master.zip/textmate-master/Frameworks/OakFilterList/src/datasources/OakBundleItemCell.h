@interface OakBundleItemCell : NSTextFieldCell
@property (nonatomic, retain) NSString* keyEquivalent;
@property (nonatomic, retain) NSString* tabTrigger;
@property (nonatomic, retain) NSAttributedString* attributedTabTrigger;
@end
