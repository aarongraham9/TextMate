#ifndef FILE_CONSTANTS_H_M6UXWBQX
#define FILE_CONSTANTS_H_M6UXWBQX

extern std::string const kLF;
extern std::string const kCR;
extern std::string const kCRLF;
extern std::string const kMIX;

extern std::string const kFileTypePlainText;

#endif /* end of include guard: FILE_CONSTANTS_H_M6UXWBQX */
