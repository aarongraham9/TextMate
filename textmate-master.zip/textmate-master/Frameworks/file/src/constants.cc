#include "constants.h"

std::string const kLF                = "\n";
std::string const kCR                = "\r";
std::string const kCRLF              = "\r\n";
std::string const kMIX               = "•";

std::string const kFileTypePlainText = "text.plain";
