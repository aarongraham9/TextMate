#import <OakAppKit/OakView.h>

@interface LiveSearchView : NSView
@property (nonatomic) NSTextField* textField;
@end
