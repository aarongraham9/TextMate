#include <editor/clipboard.h>

PUBLIC clipboard_ptr get_clipboard (NSString* pboardName);
