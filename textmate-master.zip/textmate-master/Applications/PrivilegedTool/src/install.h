#ifndef PRIVILEGED_TOOL_INSTALL_H_4IAOPZ4H
#define PRIVILEGED_TOOL_INSTALL_H_4IAOPZ4H

int install_tool (std::string const& toolPath);
int uninstall_tool ();

#endif /* end of include guard: PRIVILEGED_TOOL_INSTALL_H_4IAOPZ4H */
