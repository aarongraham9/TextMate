#ifndef LAUNCHD_H_SP1GJCZ
#define LAUNCHD_H_SP1GJCZ

int launchd_sockets ();

#endif /* end of include guard: LAUNCHD_H_SP1GJCZ */
