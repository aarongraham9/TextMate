
[Apple]: http://apple.com/ "Apple Inc."
