#ifndef RMATESERVER_H_UPCJJJ8U
#define RMATESERVER_H_UPCJJJ8U

void setup_rmate_server (bool enabled, uint32_t ip, uint16_t port);

#endif /* end of include guard: RMATESERVER_H_UPCJJJ8U */
