## TextMate version <script>document.write(TextMate.version)</script>

Alpha means that some functionality is missing or cumbersome to use, the user interface may sometimes be misleading (e.g. a button may not do what it says) and there are a few performance issues.

Overall though TextMate 2 should be quite usable.

_TextMate is a trademark of Allan Odgaard and the program is copyrighted by MacroMates Ltd., 2013._
