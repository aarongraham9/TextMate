#import <OakSystem/application.h>

int main (int argc, char const* argv[])
{
	oak::application_t app(argc, argv);
	return NSApplicationMain(argc, argv);
}
