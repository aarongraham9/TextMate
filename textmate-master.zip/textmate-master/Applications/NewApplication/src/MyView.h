@interface MyView : NSView
{
}
@end
