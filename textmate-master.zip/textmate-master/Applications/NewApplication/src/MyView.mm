#import "MyView.h"

@implementation MyView
- (void)drawRect:(NSRect)aRect
{
	NSEraseRect(aRect);
}
@end
